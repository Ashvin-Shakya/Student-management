package com.student;

import java.util.ArrayList;
import java.util.Scanner;

public class StudentService {

	Scanner scanner = new Scanner(System.in);
	ArrayList<Student> arrayList = new ArrayList<>();

	public void addStudent() {
		System.out.println("Enter Student Id");
		int id = scanner.nextInt();
		scanner.nextLine();

		System.out.println("Enter Student Name : ");
		String name = scanner.nextLine();

		System.out.println("Enter Student Age");
		int age = scanner.nextInt();
		scanner.nextLine();

		Student student = new Student(id, name, age);
		arrayList.add(student);
		System.out.println("Student Add Successfully..");
	}
	public void listStudent() {
	    if (arrayList.isEmpty()) {
	        System.out.println("Record Not Found..");
	    } else {
	        System.out.println("-------------------------------------");
	        System.out.printf("%-10s %-20s %-5s%n", "ID", "Name", "Age");
	        System.out.println("-------------------------------------");
	        for (Student student : arrayList) {
	            System.out.printf("%-10d %-20s %-5d%n", student.getId(), student.getName(), student.getAge());
		        System.out.println("-------------------------------------");
	        }
	    }
	}	
	public void deleteStudent() {
		System.out.println("Enter Student id: ");
		int id = scanner.nextInt();
		
		Student student = findStudentById(id);
		if(arrayList.remove(student)) {
			System.out.println("Student Record Delete Success");
		}else {
			System.out.println("Student Record NOt  Delete ");
		}
		
	}
	private Student findStudentById(int id) {
		
		for (Student student : arrayList) {
			if(student.getId()==id) {
				return student;
			}
		}
		return null;
	}
	public void updateStudent() {
		
		System.out.println("Enter Student Id : ");
		int id = scanner.nextInt();
		scanner.nextLine();
		
		Student student = findStudentById(id);
		if(student!= null) {
			System.out.println("Enter Student New id");
			int Id = scanner.nextInt();
			scanner.nextLine();
			
			System.out.println("Enter Student New Name: ");
			String name = scanner.nextLine();
			
			System.out.println("Enter Student New Age");
			int age = scanner.nextInt();
			scanner.nextLine();
			student.setId(Id);
			student.setName(name);
			student.setAge(age);
			
			System.out.println("Student Update Successfull");
			
		}else {
			System.out.println("Student NotUpdate Successfull");
		}
		
		
		
		
		
	}

}
